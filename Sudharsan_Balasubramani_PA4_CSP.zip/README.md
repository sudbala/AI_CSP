# CSP Code Instructions
Hello! Welcome to my CSP solver. The solving is handled by the backtracking algorithm in CSP.py. GeneralCSP houses the 
General CSP and then the specific CSPs like Map Coloring and Circuit Board all extend the General functionality. To run
tests, please use the respective testing files. Each have tests done with no heuristics, some, a combo of some, arc 
consistency, etc. Please comment ones you wouldn't like to see and then uncomment ones you would like to see. Make sure 
you have imported all necessary packages, particularly copy, and then run the python program. Enjoy!